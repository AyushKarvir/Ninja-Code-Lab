import React, { useState, useEffect } from 'react';
import { Star, ChevronLeft, ChevronRight } from 'lucide-react';

interface Testimonial {
  id: number;
  name: string;
  role: string;
  company: string;
  image: string;
  rating: number;
  content: string;
}

const Testimonials: React.FC = () => {
  const [currentSlide, setCurrentSlide] = useState(0);

  const testimonials: Testimonial[] = [
    {
      id: 1,
      name: "Sarah Chen",
      role: "Full Stack Developer",
      company: "Google",
      image: "https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=200",
      rating: 5,
      content: "CodeNinja transformed my career completely. The hands-on projects and mentorship helped me land my dream job at Google. The curriculum is perfectly structured and the instructors are world-class."
    },
    {
      id: 2,
      name: "Marcus Rodriguez",
      role: "Software Engineer",
      company: "Microsoft",
      image: "https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=200",
      rating: 5,
      content: "I went from zero coding experience to landing a six-figure job in just 6 months. The practical approach and real-world projects at CodeNinja made all the difference in my learning journey."
    },
    {
      id: 3,
      name: "Emily Johnson",
      role: "Data Scientist",
      company: "Netflix",
      image: "https://images.pexels.com/photos/1181519/pexels-photo-1181519.jpeg?auto=compress&cs=tinysrgb&w=200",
      rating: 5,
      content: "The Python for Data Science course was incredible. The instructors explain complex concepts so clearly, and the portfolio projects I built helped me stand out during interviews."
    },
    {
      id: 4,
      name: "David Kim",
      role: "Mobile Developer",
      company: "Uber",
      image: "https://images.pexels.com/photos/1040880/pexels-photo-1040880.jpeg?auto=compress&cs=tinysrgb&w=200",
      rating: 5,
      content: "CodeNinja's mobile development course was exactly what I needed. The React Native curriculum is up-to-date with industry standards, and I built 3 apps that impressed my future employers."
    }
  ];

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % testimonials.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + testimonials.length) % testimonials.length);
  };

  useEffect(() => {
    const timer = setInterval(nextSlide, 6000);
    return () => clearInterval(timer);
  }, []);

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl sm:text-5xl font-bold text-gray-900 mb-4">
            Success Stories
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Hear from our graduates who transformed their careers with CodeNinja
          </p>
        </div>

        {/* Testimonials Slider */}
        <div className="relative">
          <div className="overflow-hidden rounded-2xl">
            <div
              className="flex transition-transform duration-500 ease-in-out"
              style={{ transform: `translateX(-${currentSlide * 100}%)` }}
            >
              {testimonials.map((testimonial) => (
                <div key={testimonial.id} className="w-full flex-shrink-0">
                  <div className="bg-gradient-to-br from-gray-900 to-gray-800 text-white p-8 lg:p-12 mx-4 rounded-2xl">
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
                      {/* Testimonial Content */}
                      <div className="space-y-6">
                        {/* Stars */}
                        <div className="flex space-x-1">
                          {[...Array(testimonial.rating)].map((_, i) => (
                            <Star key={i} className="h-5 w-5 fill-yellow-400 text-yellow-400" />
                          ))}
                        </div>

                        {/* Quote */}
                        <blockquote className="text-lg lg:text-xl leading-relaxed text-gray-100">
                          "{testimonial.content}"
                        </blockquote>

                        {/* Author Info */}
                        <div>
                          <div className="text-xl font-bold text-white">{testimonial.name}</div>
                          <div className="text-orange-400 font-medium">{testimonial.role}</div>
                          <div className="text-gray-300">{testimonial.company}</div>
                        </div>
                      </div>

                      {/* Author Image */}
                      <div className="flex justify-center lg:justify-end">
                        <div className="relative">
                          <div className="absolute inset-0 bg-orange-500 rounded-2xl transform rotate-6 opacity-20"></div>
                          <img
                            src={testimonial.image}
                            alt={testimonial.name}
                            className="relative w-64 h-64 object-cover rounded-2xl shadow-2xl"
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Navigation Buttons */}
          <button
            onClick={prevSlide}
            className="absolute left-0 top-1/2 transform -translate-y-1/2 -translate-x-4 bg-white hover:bg-gray-100 text-gray-800 p-3 rounded-full shadow-lg transition-all duration-200 hover:scale-110"
          >
            <ChevronLeft className="h-6 w-6" />
          </button>

          <button
            onClick={nextSlide}
            className="absolute right-0 top-1/2 transform -translate-y-1/2 translate-x-4 bg-white hover:bg-gray-100 text-gray-800 p-3 rounded-full shadow-lg transition-all duration-200 hover:scale-110"
          >
            <ChevronRight className="h-6 w-6" />
          </button>

          {/* Dots Indicator */}
          <div className="flex justify-center mt-8 space-x-2">
            {testimonials.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentSlide(index)}
                className={`w-3 h-3 rounded-full transition-all duration-200 ${
                  currentSlide === index ? 'bg-orange-500 scale-110' : 'bg-gray-300 hover:bg-gray-400'
                }`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;