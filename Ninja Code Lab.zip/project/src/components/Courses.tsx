import React from 'react';
import { Clock, Users, Star, ArrowRight } from 'lucide-react';

interface Course {
  id: number;
  title: string;
  description: string;
  image: string;
  duration: string;
  students: string;
  rating: number;
  level: string;
  price: string;
}

const Courses: React.FC = () => {
  const courses: Course[] = [
    {
      id: 1,
      title: "Full Stack JavaScript",
      description: "Master modern web development with React, Node.js, and MongoDB. Build complete web applications from scratch.",
      image: "https://images.pexels.com/photos/11035380/pexels-photo-11035380.jpeg?auto=compress&cs=tinysrgb&w=800",
      duration: "12 weeks",
      students: "2.5K",
      rating: 4.9,
      level: "Beginner to Advanced",
      price: "$299"
    },
    {
      id: 2,
      title: "Python for Data Science",
      description: "Learn Python programming and dive into data analysis, machine learning, and AI with hands-on projects.",
      image: "https://images.pexels.com/photos/1181677/pexels-photo-1181677.jpeg?auto=compress&cs=tinysrgb&w=800",
      duration: "10 weeks",
      students: "1.8K",
      rating: 4.8,
      level: "Beginner",
      price: "$249"
    },
    {
      id: 3,
      title: "Mobile App Development",
      description: "Create stunning iOS and Android apps using React Native. Deploy to app stores and build your portfolio.",
      image: "https://images.pexels.com/photos/607812/pexels-photo-607812.jpeg?auto=compress&cs=tinysrgb&w=800",
      duration: "8 weeks",
      students: "1.2K",
      rating: 4.7,
      level: "Intermediate",
      price: "$199"
    },
    {
      id: 4,
      title: "DevOps & Cloud Computing",
      description: "Master Docker, Kubernetes, AWS, and CI/CD pipelines. Learn to deploy and scale applications in the cloud.",
      image: "https://images.pexels.com/photos/1181263/pexels-photo-1181263.jpeg?auto=compress&cs=tinysrgb&w=800",
      duration: "14 weeks",
      students: "950",
      rating: 4.6,
      level: "Advanced",
      price: "$399"
    },
    {
      id: 5,
      title: "UI/UX Design Fundamentals",
      description: "Learn design principles, user research, prototyping, and create beautiful, user-centered digital experiences.",
      image: "https://images.pexels.com/photos/196644/pexels-photo-196644.jpeg?auto=compress&cs=tinysrgb&w=800",
      duration: "6 weeks",
      students: "1.5K",
      rating: 4.8,
      level: "Beginner",
      price: "$179"
    },
    {
      id: 6,
      title: "Cybersecurity Essentials",
      description: "Understand security fundamentals, ethical hacking, and protect systems from cyber threats.",
      image: "https://images.pexels.com/photos/60504/security-protection-anti-virus-software-60504.jpeg?auto=compress&cs=tinysrgb&w=800",
      duration: "10 weeks",
      students: "800",
      rating: 4.7,
      level: "Intermediate",
      price: "$329"
    }
  ];

  return (
    <section id="courses" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl sm:text-5xl font-bold text-gray-900 mb-4">
            Popular Courses
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Choose from our comprehensive selection of coding courses designed by industry experts
          </p>
        </div>

        {/* Courses Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {courses.map((course) => (
            <div
              key={course.id}
              className="group bg-white rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 overflow-hidden"
            >
              {/* Course Image */}
              <div className="relative overflow-hidden">
                <img
                  src={course.image}
                  alt={course.title}
                  className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-300"
                />
                <div className="absolute top-4 left-4 bg-orange-500 text-white px-3 py-1 rounded-full text-sm font-medium">
                  {course.level}
                </div>
                <div className="absolute top-4 right-4 bg-white bg-opacity-90 text-gray-900 px-3 py-1 rounded-full text-sm font-bold">
                  {course.price}
                </div>
              </div>

              {/* Course Content */}
              <div className="p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-2 group-hover:text-orange-500 transition-colors duration-200">
                  {course.title}
                </h3>
                <p className="text-gray-600 mb-4 line-clamp-3">
                  {course.description}
                </p>

                {/* Course Meta */}
                <div className="flex items-center justify-between text-sm text-gray-500 mb-4">
                  <div className="flex items-center space-x-1">
                    <Clock className="h-4 w-4" />
                    <span>{course.duration}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Users className="h-4 w-4" />
                    <span>{course.students}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                    <span>{course.rating}</span>
                  </div>
                </div>

                {/* CTA Button */}
                <button className="group/btn w-full bg-gray-900 hover:bg-orange-500 text-white py-3 rounded-lg font-semibold transition-all duration-200 flex items-center justify-center space-x-2">
                  <span>Enroll Now</span>
                  <ArrowRight className="h-4 w-4 group-hover/btn:translate-x-1 transition-transform duration-200" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Courses;